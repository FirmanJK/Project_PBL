<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "bebas_tanggungan_app";

$koneksi = mysqli_connect($host, $username, $password, $dbname);

//AUTH
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $cekUser = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
    $hitung = mysqli_num_rows($cekUser);
    // $ambilData = 
    if ($hitung > 0) {
        $ambilData = mysqli_fetch_array($cekUser);
        $role = $ambilData['role'];

        if ($role == 'admin') {
            $_SESSION['log'] = 'Logged';
            $_SESSION['role'] = 'admin';
            header("location:../user/superadmin");
        } else {
            $_SESSION['log'] = 'Logged';
            $_SESSION['role'] = 'user';
            header("location:../user/mahasiswa");
        }


    } else {
        echo "<script>alert('Username atau Password Salah')</script>";
    }
}

?>